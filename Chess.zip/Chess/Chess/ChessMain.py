import pygame as p
import numpy as np
#from Chess import GameState
from multiprocessing import Process,Queue
import ChessEngine,SmartMoveFinder
import tkinter as tk
from tkinter import messagebox
playerOne = False
playerTwo = False
BOARD_HEIGH=680#
BOARD_WIDTH=680
MOVE_LOG_PANEL_WIDTH= 320
MOVE_LOG_PANEL_HEIGH=BOARD_HEIGH
DIMENSION=8 # KICH THUOC LA 8*8
SQ_SIZE=BOARD_HEIGH // DIMENSION
MAX_FPS=15
IMAGES={}
SOUNDS={}
# tai anh len
def loadImages():
    pieces =['wp','wR','wN','wB','wK','wQ','bp','bR','bN','bB','bK','bQ']
    for piece in pieces:
        IMAGES[piece]=p.transform.scale(p.image.load("Chess\\images\\"+piece+".png"),(SQ_SIZE,SQ_SIZE))  

def play_move_sound():
    # Cài đặt âm thanh
    frequency = 700       # Tần số âm (Hz)
    duration_ms = 100     # Độ dài âm (ms)
    sample_rate = 44100   # Tần số lấy mẫu

    # Tạo sóng sin
    t = np.linspace(0, duration_ms / 1000, int(sample_rate * duration_ms / 1000), False)
    wave = 0.5 * np.sin(2 * np.pi * frequency * t)

    # Chuyển sóng sang định dạng âm thanh 16-bit
    audio = (wave * 32767).astype(np.int16)
    stereo = np.column_stack((audio, audio))  # Âm thanh stereo 2 kênh

    # Phát âm thanh
    sound = p.sndarray.make_sound(stereo)
    sound.play()

def play_end_game_sound():
    frequency = 220       # Âm trầm hơn
    duration_ms = 600     # Kéo dài hơn
    sample_rate = 44100

    t = np.linspace(0, duration_ms / 1000, int(sample_rate * duration_ms / 1000), False)
    wave = 0.5 * np.sin(2 * np.pi * frequency * t)

    # Có thể thêm hiệu ứng fade-out
    fade = np.linspace(1, 0, len(wave))
    wave *= fade

    audio = (wave * 32767).astype(np.int16)
    stereo = np.column_stack((audio, audio))

    sound = p.sndarray.make_sound(stereo)
    sound.play()



def main():
    p.init()
    
    
     # Gọi giao diện chọn chế độ trước khi bắt đầu game
    choose_mode()

    screen= p.display.set_mode((BOARD_WIDTH+MOVE_LOG_PANEL_WIDTH,BOARD_HEIGH))
    clock=p.time.Clock()
    screen.fill(p.Color("White"))
    moveLogFont=p.font.SysFont('Arial',20,False,False)
    gs=ChessEngine.GameState()
    validMoves= gs.getValidMoves() #
    moveMade =False# flag variable for when a move is made
    animate=False
    loadImages() # only do thi once, before the while loop
    
    running=True
    sqSelected=() # no square is selected,keep track of the last click of the user
    playerClicks=[]# theo dõi các cú nhấp chuột của người chươi
    gameOver=False
    highlightSquaresActive = False  # Biến trạng thái quản lý việc làm nổi bật ô
    start_square = None
    end_square = None
    #playerOne=False#nếu một con người đang chơi màu trắng thì điều này sẽ đúng. nếu một Ai đang chơi, thì sai
    #playerTwo=False#giống như trên nhưng dành cho màu đen
    # Sử dụng playerOne và playerTwo từ giao diện Tkinter
    global playerOne, playerTwo
    AIThinking=False
    moveFinderProcess=None
    moveUndone=False
    playerLastMove = None# Lưu lại nước đi gần nhất của người chơi (dùng để highlight)
    aiLastMove = None# Lưu lại nước đi gần nhất của AI (dùng để highlight)
    while running:
        humanTurn=(gs.whiteToMove and playerOne )or(not gs.whiteToMove and playerTwo)
        for e in p.event.get():
            if e.type== p.QUIT:
                running=False
            # mouse handler
            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver :
                    location=p.mouse.get_pos()#(x,y) vị trí chuột
                    col=location[0]//SQ_SIZE
                    row=location[1]//SQ_SIZE
                    if sqSelected == (row,col) or col>=8: # ng dùng kik đúp chuột vào ô vuông
                        sqSelected=()# deselect
                        playerClicks=[] #clear player click
                    else:
                        sqSelected=(row,col)
                        playerClicks.append(sqSelected)# append cho cả người 1 và 2 kik chuột
                    if len(playerClicks)==2 and humanTurn:
                        move =ChessEngine.Move(playerClicks[0],playerClicks[1],gs.board)
                        print(move.getChessNotation())
                        for i in range(len(validMoves)):
                            if move == validMoves[i]:
                                gs.makeMove(validMoves[i]) # thực hiện nước đi
                                gs.updateRepetitionTable()  # Cập nhật trạng thái bàn cờ
                                start_square = playerClicks[0]  # Lưu ô bắt đầu
                                end_square = playerClicks[1]  # Lưu ô đích
                                playerLastMove = validMoves[i]

                                moveMade=True   # đánh dấu nước đi được thực hiện
                                animate=True
                                highlightSquaresActive = True  # Bắt đầu làm nổi bật các ô
                                play_move_sound()  # Gọi hàm phát âm thanh ở đây
                                sqSelected=() # reset user click
                                playerClicks=[]
                        if not moveMade:
                            playerClicks=[sqSelected]
            #key handler
            elif e.type ==p.KEYDOWN:
                if e.key == p.K_z: # nhấn 'z' để đi lại
                    gs.undoMove()
                    
                    moveMade=True
                    animate=False
                    gameOver=False
                    if AIThinking:
                        moveFinderProcess.terminate()
                        AIThinking=False
                    moveUndone=True
                    
                if e.key==p.K_r:# nhấn 'r' để chơi lại ván mới
                    gs=ChessEngine.GameState()
                    validMoves=gs.getValidMoves()
                    #gs.updateRepetitionTable()  # Cập nhật lại sau khi undo
                    sqSelected=()
                    playerClicks=[]
                    moveMade=False
                    animate=False
                    gameOver=False
                    if AIThinking:
                        moveFinderProcess.terminate()
                        AIThinking=False
                    moveUndone=True

         #Ai move finder
        if not gameOver and not humanTurn and not moveUndone    :# Nếu game chưa kết thúc và không phải lượt của người chơi
            if not AIThinking:
                AIThinking=True
                print('thinking...')
                returnQueue=Queue() # used to pass data between threads
                moveFinderProcess=Process(target=SmartMoveFinder.findBestMove,args=(gs,validMoves,returnQueue))
                moveFinderProcess.start( )# call findBestMove(gs,validMove,returnQueue)

            if not moveFinderProcess.is_alive():
                print('done thinking')
                AIMove=returnQueue.get()

                if AIMove is None:
                    AIMove =SmartMoveFinder.findRandomMove(validMoves)

                # ⬇ Thêm dòng này để lưu lại ô bắt đầu và kết thúc
                start_square = AIMove.startRow, AIMove.startCol
                end_square = AIMove.endRow, AIMove.endCol

                gs.makeMove(AIMove) # Thực hiện nước đi của AI
                gs.updateRepetitionTable()  # 🔥 THÊM DÒNG NÀY để cập nhật trạng thái lặp
                moveMade=True# Đánh dấu rằng đã có nước đi được thực hiện
                animate=True# Bật hiệu ứng di chuyển'''
                AIThinking=False

                aiLastMove = AIMove  # lưu lại nước đi của AI
                play_move_sound()  # Gọi hàm phát âm thanh ở đây
    

        # Nếu có nước đi được thực hiện
        if moveMade:
            if animate:
                animateMove(gs.moveLog[-1],screen,gs.board,clock,start_square,end_square)# Thực hiện hiệu ứng di chuyển
            validMoves = gs.getValidMoves()# Cập nhật lại danh sách nước đi hợp lệ
            moveMade=False  # Đặt lại biến moveMade để chờ nước đi tiếp theo
            animate=False # Đặt lại animate để không chạy animation cho nước đi tiếp theo
            moveUndone=False

        drawGameState(screen, gs, validMoves, sqSelected, moveLogFont,
              highlightSquaresActive, start_square, end_square,
              lastMovePlayer=playerLastMove, lastMoveOpponent=aiLastMove)

        '''if gs.checkmate or gs.stalemate:
            gameOver=True
            
            drawEndGameText(screen,text='Stalemate'if gs.stalemate else 'Black wins by checkmate'if gs.whiteToMove else'White wins by checkmate')
            p.display.update()  # Cập nhật màn hình'''
        if gs.checkMade:
            gameOver=True
            if gs.whiteToMove:
                drawEndGameText(screen,'Black wins by checkmate')
            else:
                drawEndGameText(screen,'White wins by checkmate')
        elif gs.staleMade:
            gameOver=True
            drawEndGameText(screen,'Stalemate')
        elif any(value >= 3 for value in gs.repetitionTable.values()):  # Kiểm tra trạng thái lặp 3 lần
            gameOver = True
            drawEndGameText(screen, 'Draw by threefold repetition')
            # Thêm âm thanh khi hòa do lặp lại
            play_end_game_sound()  # Gọi hàm phát âm thanh hòa do lặp lại ở đây

        clock.tick(MAX_FPS)
        p.display.flip()
#Di chuyển hoạt ảnh/làm nổi bật, đặt lại và kết thúc văn bản trò chơi
def highlightSquares(screen, gs, validMoves, sqSelected, highlightSquaresActive, lastMovePlayer=None, lastMoveOpponent=None):
    # Nếu có ô được chọn
    if sqSelected != ():  
        r, c = sqSelected  # Gán giá trị cho r và c
        if gs.board[r][c][0] == ('w' if gs.whiteToMove else 'b'):  # Kiểm tra quân cờ của người chơi hiện tại
            # Highlight ô được chọn
            s = p.Surface((SQ_SIZE, SQ_SIZE))
            s.set_alpha(100)
            s.fill(p.Color('deeppink'))  # Màu ô quân cờ đã chọn
            screen.blit(s, (c * SQ_SIZE, r * SQ_SIZE))

            # Highlight các nước đi từ ô đã chọn
            s.fill(p.Color(0, 0, 139))  # Màu các ô có thể di chuyển đến
            for move in validMoves:
                if move.startRow == r and move.startCol == c:
                    screen.blit(s, (move.endCol * SQ_SIZE, move.endRow * SQ_SIZE))

    # Highlight ô đích cho tất cả các nước đi nếu highlightSquaresActive là True
    if highlightSquaresActive:  
        
        s = p.Surface((SQ_SIZE, SQ_SIZE))
        s.set_alpha(100)
        '''
        for move in validMoves:
            # Highlight ô đích của quân cờ với màu xanh lá cây
            s.fill(p.Color('lightgreen'))  
            screen.blit(s, (move.endCol * SQ_SIZE, move.endRow * SQ_SIZE))'''

        # Highlight ô bắt đầu và ô kết thúc của lần di chuyển gần nhất (nước đi của người chơi)
        if lastMovePlayer:  # Nếu có lần di chuyển của người chơi trước đó
            startRow, startCol = lastMovePlayer.startRow, lastMovePlayer.startCol
            endRow, endCol = lastMovePlayer.endRow, lastMovePlayer.endCol

            # Highlight ô bắt đầu với màu xanh dương
            s.fill(p.Color('deepskyblue'))  # Màu ô bắt đầu
            screen.blit(s, (startCol * SQ_SIZE, startRow * SQ_SIZE))

            # Highlight ô kết thúc với màu đỏ
            s.fill(p.Color('red'))  # Màu ô kết thúc
            screen.blit(s, (endCol * SQ_SIZE, endRow * SQ_SIZE))

        # Highlight ô bắt đầu và ô kết thúc của lần di chuyển gần nhất (nước đi của đối thủ)
        if lastMoveOpponent:  # Nếu có lần di chuyển của đối thủ trước đó
            startRow, startCol = lastMoveOpponent.startRow, lastMoveOpponent.startCol
            endRow, endCol = lastMoveOpponent.endRow, lastMoveOpponent.endCol

            # Highlight ô bắt đầu với màu vàng
            s.fill(p.Color('yellow'))  # Màu ô bắt đầu của đối thủ
            screen.blit(s, (startCol * SQ_SIZE, startRow * SQ_SIZE))

            # Highlight ô kết thúc với màu cam
            s.fill(p.Color('orange'))  # Màu ô kết thúc của đối thủ
            screen.blit(s, (endCol * SQ_SIZE, endRow * SQ_SIZE))


    # --- Nổi bật tướng bị chiếu ---
    if gs.inCheck():  # Kiểm tra nếu tướng bị chiếu
        kingLocation = gs.whiteKingLocation if gs.whiteToMove else gs.blackKingLocation
        s = p.Surface((SQ_SIZE, SQ_SIZE)) 
        
        # Đổi màu ô của tướng bị chiếu (màu đỏ hoặc màu bạn muốn)
        s.fill(p.Color('black'))  # Màu đỏ để đánh dấu tướng bị chiếu
        screen.blit(s, (kingLocation[1] * SQ_SIZE, kingLocation[0] * SQ_SIZE))




def drawGameState(screen, gs, validMoves, sqSelected, moveLogFont,
                  highlightSquaresActive, start_square, end_square,
                  lastMovePlayer=None, lastMoveOpponent=None):
    drawBoard(screen, start_square, end_square)  # Vẽ bàn cờ

    # Truyền thêm lastMovePlayer và lastMoveOpponent vào để highlight nước đi
    highlightSquares(screen, gs, validMoves, sqSelected,
                     highlightSquaresActive, lastMovePlayer, lastMoveOpponent)

    drawPieces(screen, gs.board)  # Vẽ các quân cờ
    drawMoveLog(screen, gs, moveLogFont)  # Vẽ nhật ký nước đi

'''
def drawBoard(screen):
    global colors
    colors=[p.Color("yellow"),p.Color("green")] # màu ô cờ
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color=colors[((r+c)%2)]
            p.draw.rect(screen,color,p.Rect(c*SQ_SIZE,r*SQ_SIZE,SQ_SIZE,SQ_SIZE))'''

def drawBoard(screen, start_square, end_square):
    global colors
    colors = [p.Color("yellow"), p.Color("green")]  # Màu ô cờ

    for r in range(DIMENSION):
        for c in range(DIMENSION):
            # Chọn màu sáng hoặc tối cho ô cờ
            color = colors[((r + c) % 2)]
            
            # Vẽ ô
            p.draw.rect(screen, color, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

            # Vẽ màu cho ô bắt đầu (ô đỏ) và ô đích (ô xanh)
            if (r, c) == start_square:
                p.draw.rect(screen, p.Color("red"), p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))
            elif (r, c) == end_square:
                p.draw.rect(screen, p.Color("blue"), p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

    # Vẽ các quân cờ (giả sử bạn có hàm drawPieces)
    #drawPieces(screen)

    
def drawPieces(screen,board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece = board[r][c]
            if piece !="--":
                screen.blit(IMAGES[piece],p.Rect(c*SQ_SIZE,r*SQ_SIZE,SQ_SIZE,SQ_SIZE))
'''
def set_mode(mode, root):
    global playerOne, playerTwo
    if mode == "PvP":
        playerOne = True
        playerTwo = True
    elif mode == "PvE":
        playerOne = True
        playerTwo = False
    elif mode == "EvE":
        playerOne = False
        playerTwo = False

    messagebox.showinfo("Chế độ chơi", f"Chế độ đã chọn: {mode}")
    root.destroy()  # Đóng cửa sổ Tkinter

def choose_mode():
    root = tk.Tk()
    root.title("Chọn chế độ chơi")

    tk.Label(root, text="Chọn chế độ chơi:", font=("Arial", 14)).pack(pady=10)
    tk.Button(root, text="Người vs Người", command=lambda: set_mode("PvP", root)).pack(pady=5)
    tk.Button(root, text="Người vs Máy", command=lambda: set_mode("PvE", root)).pack(pady=5)
    tk.Button(root, text="Máy vs Máy", command=lambda: set_mode("EvE", root)).pack(pady=5)

    root.mainloop()'''
import tkinter as tk

import tkinter as tk
from tkinter import messagebox

def choose_mode():
    global playerOne, playerTwo

    def set_mode(mode):
        global playerOne, playerTwo
        if mode == "PvP":
            playerOne = True
            playerTwo = True
        elif mode == "PvE":
            playerOne = False
            playerTwo = True
        elif mode == "EvE":
            playerOne = False
            playerTwo = False
        root.destroy()  # Đóng cửa sổ ngay sau khi chọn chế độ

    def on_closing():
        if messagebox.askokcancel("Thoát", "Bạn có chắc muốn thoát không?"):
            root.destroy()
            exit()  # Thoát hẳn chương trình

    root = tk.Tk()
    root.title("Chọn chế độ chơi")
    root.protocol("WM_DELETE_WINDOW", on_closing)  # Gắn sự kiện đóng cửa sổ
    root.geometry("1000x680")  # Đặt kích thước cửa sổ ngang với cửa sổ chơi cờ
    root.configure(bg="lightblue")  # Đặt màu nền nhẹ
    # Căn giữa cửa sổ
    root.update_idletasks()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    window_width = 1000
    window_height = 680
    x = (screen_width - window_width) // 2
    y = (screen_height - window_height) // 2
    root.geometry(f"{window_width}x{window_height}+{x}+{y-30}")

    # Tạo frame để căn giữa nội dung
    frame = tk.Frame(root, bg="lightblue")
    frame.pack(expand=True)

    # Tiêu đề
    tk.Label(frame, text="Chọn chế độ chơi", font=("Arial", 40, "bold"), bg="lightblue").pack(pady=40)

    button_font = ("Arial", 30, "bold")  # Tăng kích thước chữ
    button_width = 15  # Độ rộng nút

    # Các nút lựa chọn
    tk.Button(frame, text="Người vs Người", font=button_font, width=button_width, command=lambda: set_mode("PvP")).pack(pady=20)
    tk.Button(frame, text="Người vs Máy", font=button_font, width=button_width, command=lambda: set_mode("PvE")).pack(pady=20)
    tk.Button(frame, text="Máy vs Máy", font=button_font, width=button_width, command=lambda: set_mode("EvE")).pack(pady=20)

    root.mainloop()



def drawMoveLog(screen,gs,font):
    moveLogRect=p.Rect(BOARD_WIDTH,0,MOVE_LOG_PANEL_WIDTH,MOVE_LOG_PANEL_HEIGH)
    p.draw.rect(screen,p.Color("black"),moveLogRect)
    moveLog=gs.moveLog
    moveTexts=[]
    for i in range(0,len(moveLog),2):
        moveString=str(i//2+1)+" " + str(moveLog[i]) +" "
        if i+1<len(moveLog):
            moveString+=str(moveLog[i+1])+" "
        moveTexts.append(moveString)

    movesPerRow=3
    padding=5
    textY=padding
    lineSpacing=2
    for i in range (0,len(moveTexts),movesPerRow):
        text=""
        for j in range(movesPerRow):
            if i+j<len(moveTexts):
                text+=moveTexts[i+j]
        textObject=font.render(text,0,p.Color('white'))# Tạo đối tượng văn bản với màu đen  
        #Xác định vị trí hiển thị văn bản, căn giữa màn hình 
        textLocation=moveLogRect.move(padding,textY)
        screen.blit(textObject,textLocation)# hiển thị kêt quả lên màn hình  
        textY+=textObject.get_height()+ lineSpacing

    
'''
def animateMove(move,screen,board ,clock):
    global colors# Sử dụng biến colors toàn cục để xác định màu ô cờ  
    # Tính toán khoảng cách hàng và cột mà quân cờ di chuyển
    dR=move.endRow-move.startRow
    dC=move.endCol-move.startCol

    framesPerSquare=10  # Số frame cho mỗi ô di chuyển (tốc độ animation) 
    frameCount=(abs(dR)+abs(dC))*framesPerSquare# Tổng số frame animation 
     # Vòng lặp tạo hiệu ứng di chuyển từng bước
    for frame in range(frameCount+1):
        # Tính toán vị trí hiện tại của quân cờ trong animation  
        r,c=(move.startRow+dR*frame/frameCount,move.startCol+dC*frame/frameCount)
        drawBoard(screen)# Vẽ bàn cờ  
        drawPieces(screen,board)# Vẽ tất cả quân cờ trên bàn
        # Xác định màu của ô đích  
        color=colors[(move.endRow+move.endCol)%2]
        endSquare =p.Rect(move.endCol*SQ_SIZE,move.endRow*SQ_SIZE,SQ_SIZE,SQ_SIZE)
        p.draw.rect(screen,color,endSquare)# Tô màu lại ô đích  
         # Nếu có quân cờ bị ăn, vẽ lại nó trước khi đặt quân mới lên 
        if move.pieceCaptured !='--':
            if move.isEnpassantMove:
                enPassantRow=(move.endRow+1)if move.pieceCaptured[0]=='b'else move.endRow-1
                endSquare =p.Rect(move.endCol*SQ_SIZE,enPassantRow*SQ_SIZE,SQ_SIZE,SQ_SIZE)
            screen.blit(IMAGES[move.pieceCaptured],endSquare)
        # Vẽ quân cờ đang di chuyển tại vị trí hiện tại của animation 
        #if move.pieceCaptured !='--':
        if move.pieceMoved !='--':
            screen.blit(IMAGES[move.pieceMoved],p.Rect(c*SQ_SIZE,r*SQ_SIZE,SQ_SIZE,SQ_SIZE))
        p.display.flip()# Cập nhật màn hình  
        clock.tick(60)# Giới hạn tốc độ khung hình để animation mượt mà 
        
    '''
def animateMove(move, screen, board, clock,start_square,end_square):
    global colors  # Sử dụng biến colors toàn cục để xác định màu ô cờ  
    global highlightSquaresActive
    highlightSquaresActive = True  # Bắt đầu làm nổi bật ô
    # Tính toán khoảng cách hàng và cột mà quân cờ di chuyển
    dR = move.endRow - move.startRow
    dC = move.endCol - move.startCol

    framesPerSquare = 10  # Số frame cho mỗi ô di chuyển (tốc độ animation) 
    frameCount = (abs(dR) + abs(dC)) * framesPerSquare  # Tổng số frame animation 

    # Vòng lặp tạo hiệu ứng di chuyển từng bước
    for frame in range(frameCount + 1):
        # Tính toán vị trí hiện tại của quân cờ trong animation  
        r, c = (move.startRow + dR * frame / frameCount, move.startCol + dC * frame / frameCount)
        
        drawBoard(screen,start_square,end_square) # Vẽ bàn cờ  
        drawPieces(screen, board)  # Vẽ tất cả quân cờ trên bàn

        # Làm nổi bật ô xuất phát
        startSquareColor = p.Color('lightblue')  # Màu ô xuất phát
        startSquare = p.Rect(move.startCol * SQ_SIZE, move.startRow * SQ_SIZE, SQ_SIZE, SQ_SIZE)
        p.draw.rect(screen, startSquareColor, startSquare)  # Tô màu ô xuất phát

        # Làm nổi bật ô đích
        endSquareColor = p.Color('lightblue')  # Màu ô đích
        endSquare = p.Rect(move.endCol * SQ_SIZE, move.endRow * SQ_SIZE, SQ_SIZE, SQ_SIZE)
        p.draw.rect(screen, endSquareColor, endSquare)  # Tô màu ô đích

        # Nếu có quân cờ bị ăn, vẽ lại nó trước khi đặt quân mới lên 
        if move.pieceCaptured != '--':
            if move.isEnpassantMove:
                enPassantRow = (move.endRow + 1) if move.pieceCaptured[0] == 'b' else move.endRow - 1
                endSquare = p.Rect(move.endCol * SQ_SIZE, enPassantRow * SQ_SIZE, SQ_SIZE, SQ_SIZE)
            screen.blit(IMAGES[move.pieceCaptured], endSquare)

        # Vẽ quân cờ đang di chuyển tại vị trí hiện tại của animation 
        if move.pieceMoved != '--':
            screen.blit(IMAGES[move.pieceMoved], p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

        p.display.flip()  # Cập nhật màn hình  
        clock.tick(60)  # Giới hạn tốc độ khung hình để animation mượt mà 

    # Sau khi di chuyển xong, giữ màu tại 2 ô trước khi di chuyển và ô đích thêm một chút thời gian
    highlightSquaresActive = False  # Tắt làm nổi bật sau khi đối thủ di chuyển xong




def drawEndGameText(screen,text):
    font=p.font.SysFont('Helvitca',60,True,False)# Khởi tạo font chữ Helvetica, cỡ 32, in đậm, không in nghiêng 
    textObject=font.render(text,0,p.Color('Red'))# Tạo đối tượng văn bản với màu đen  
    # Xác định vị trí hiển thị văn bản, căn giữa màn hình 
    textLocation=p.Rect(0,0,BOARD_WIDTH,BOARD_HEIGH).move(BOARD_WIDTH/2-textObject.get_width()/2,BOARD_HEIGH/2-textObject.get_height()/2)
    screen.blit(textObject,textLocation)# hiển thị kêt quả lên màn hình  

    #textObject=font.render(text,0,p.Color('Gray'))
    #screen.blit(textObject,textLocation.move(2,2))


if __name__=="__main__":
    main()
