'''
this is 
'''
import hashlib

class GameState():
    def __init__(self):
        # tao ban co
        self.board=[
            ["bR","bN","bB","bQ","bK","bB","bN","bR"],
            ["bp","bp","bp","bp","bp","bp","bp","bp"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["wp","wp","wp","wp","wp","wp","wp","wp"],
            ["wR","wN","wB","wQ","wK","wB","wN","wR"]
            # ["bR","--","--","bQ","bK","--","--","--"],
            # ["--","--","--","--","--","--","bp","--"],
            # ["--","--","--","--","--","--","--","--"],
            # ["--","--","--","--","--","--","--","--"],
            # ["--","--","--","--","--","--","--","--"],
            # ["--","--","--","--","--","--","--","--"],
            # ["wp","--","wp","--","--","--","--","--"],
            # ["--","--","--","wQ","wK","--","--","wR"]
            
        ]
        self.moveFunctions={"p":self.getPawnMoves,"R":self.getRookMoves,"N":self.getKnightMoves,
                            "B":self.getBishopMoves,"Q":self.getQueenMoves,"K":self.getKingMoves}


        self.whiteToMove=True
        self.moveLog=[]
        self.repetitionTable = {}  # Lưu trạng thái bàn cờ
        self.updateRepetitionTable()  # Cập nhật trạng thái ban đầu
        self.whiteKingLocation=(7,4)
        self.blackKingLocation=(0,4)
        #self.inCheck =False
        self.checkMade=False
        self.staleMade=False
        self.enpassantPossible=()
        self.enpassantPossibleLog=[self.enpassantPossible]
        self.currentcastlingRight=CastleRights(True,True,True,True)
        self.castleRightsLog=[CastleRights(self.currentcastlingRight.wks,self.currentcastlingRight.bks,
                                           self.currentcastlingRight.wqs,self.currentcastlingRight.bqs)]


        self.pins=[] # danh sách quân cờ bị gim
        self.checks=[]# danh sach nước chiếu tướng

        # Thêm thuộc tính half_moves và full_moves
        self.half_moves = 0  # Số lượt đi không có ăn quân hoặc di chuyển quân
        self.full_moves = 1  # Tổng số lượt đi trong ván đấu

        #castling rights
    # Phương thức fen() để tạo chuỗi FEN
    def fen(self):
        # Bàn cờ
        rows = []  # Danh sách chứa chuỗi FEN cho từng hàng trên bàn cờ
        for row in self.board:  # Duyệt từng hàng (8 hàng)
            empty_count = 0     # Đếm số ô trống liên tiếp
            row_fen = ""        # Chuỗi FEN cho hàng hiện tại

            for square in row:  # Duyệt từng ô trong hàng
                if square == "--":
                    empty_count += 1  # Đếm ô trống
                else:
                    if empty_count > 0:
                        row_fen += str(empty_count)  # Ghi lại số ô trống trước đó
                        empty_count = 0
                    row_fen += square  # Ghi quân cờ (vd: "wp", "bK")
            
            if empty_count > 0:
                row_fen += str(empty_count)  # Ghi số ô trống cuối hàng nếu có
            
            rows.append(row_fen)  # Thêm chuỗi FEN của hàng vào danh sách

        
        # Tạo phần bàn cờ của chuỗi FEN
        board_fen = "/".join(rows)
        
        # Tạo phần lượt đi (white hoặc black)
        turn_fen = 'w' if self.whiteToMove else 'b'
        
        # Tạo phần castling
        castling_fen = self.castling_fen()
        
        # Tạo phần en passant
        en_passant_fen = self.squareToAlgebraic(self.enpassantPossible) if isinstance(self.enpassantPossible, tuple) and self.enpassantPossible else '-'
        
        # Tạo phần số lượt đi và số lượt đi trong ván
        half_moves = self.half_moves
        full_moves = self.full_moves
        
        return f"{board_fen} {turn_fen} {castling_fen} {en_passant_fen} {half_moves} {full_moves}"

    # Phương thức castling_fen() để tạo chuỗi quyền castling
    def castling_fen(self):
        castling = ""
        if self.currentcastlingRight.wks:
            castling += "K"
        if self.currentcastlingRight.wqs:
            castling += "Q"
        if self.currentcastlingRight.bks:
            castling += "k"
        if self.currentcastlingRight.bqs:
            castling += "q"
        return castling if castling else '-'
    
    def squareToAlgebraic(self, square):
        if not square:
            return '-'
        row, col = square
        files = 'abcdefgh'
        ranks = '87654321'
        return files[col] + ranks[row]

    
    '''
    def updateRepetitionTable(self):
        """Cập nhật trạng thái bàn cờ vào bảng băm, nhưng tránh lặp 3 lần nếu có nước khác."""
        board_state = str(self.board)
        if board_state in self.repetitionTable:
            self.repetitionTable[board_state] += 1
        else:
            self.repetitionTable[board_state] = 1

        # Nếu trạng thái đã lặp lại 2 lần, kiểm tra xem còn nước đi nào khác không
        if self.repetitionTable[board_state] == 2:
            alternativeMoveExists = any(
                str(self.boardAfterMove(move)) not in self.repetitionTable
                for move in self.getValidMoves()
            )

            if alternativeMoveExists:
                return  # Không đánh dấu hòa nếu có nước đi khác

        if self.repetitionTable[board_state] >= 3:
            self.staleMade = True  # Hòa do lặp lại 3 lần
            print("🚨 Hòa do lặp lại trạng thái bàn cờ 3 lần!")'''
    
    def updateRepetitionTable(self):
        """Theo dõi trạng thái bàn cờ và chỉ hòa nếu lặp lại lần 3 và người chơi vẫn không tránh."""
        board_state = str(self.board)

        if board_state in self.repetitionTable:
            self.repetitionTable[board_state] += 1
        else:
            self.repetitionTable[board_state] = 1

        # Nếu vừa chạm mốc 2 lần (chuẩn bị đến 3), kiểm tra có thể tránh không
        if self.repetitionTable[board_state] == 2:
            alternativeExists = any(
                str(self.boardAfterMove(move)) not in self.repetitionTable
                for move in self.getValidMoves()
            )

            if alternativeExists:
                return  # Còn nước đi để né -> chưa hòa

        # Nếu thực sự cố tình lặp lại đến lần 3
        if self.repetitionTable[board_state] >= 3:
            self.staleMade = True
            print("🚨 Hòa do cố tình lặp lại trạng thái 3 lần!")


    def boardAfterMove(self, move):
        """Trả về trạng thái bàn cờ sau khi thực hiện một nước đi."""
        tempBoard = [row[:] for row in self.board]  # Sao chép bàn cờ
        tempBoard[move.endRow][move.endCol] = tempBoard[move.startRow][move.startCol]
        tempBoard[move.startRow][move.startCol] = "--"
        return tempBoard

    def makeMove(self,move):
        
        if isinstance(move, NullMove):  # Kiểm tra nếu là NullMove
            return  # Không làm gì cả nếu là NullMove
    
        self.board[move.startRow][move.startCol]="--"
        self.board[move.endRow][move.endCol]=move.pieceMoved
        self.moveLog.append(move)
        self.whiteToMove= not self.whiteToMove
        # cập nhật vị trí của vua(đi được) nếu di chuyển
        if move.pieceMoved=='wK':
            self.whiteKingLocation=(move.endRow,move.endCol)
        elif move.pieceMoved=='bK':
            self.blackKingLocation=(move.endRow,move.endCol)
        
        move.enpassantPossibleBeforeMove = self.enpassantPossible

        # pawn promotion
        if move.isPawnPromotion:
            self.board[move.endRow][move.endCol]=move.pieceMoved[0]+'Q'
        
        #bắt tôt qua đường
        if move.isEnpassantMove:
            #self.board[move.startRow][move.endCol]='--'
            self.board[move.endRow + (1 if move.pieceMoved == 'wp' else -1)][move.endCol] = '--' # xóa tôt qua đường
        
        if move.pieceMoved[1]=='p' and abs(move.startRow-move.endRow)==2:
            self.enpassantPossible= ((move.startRow+move.endRow)//2,move.startCol)
        else:
            self.enpassantPossible=None
        
        #castle move
        if move.isCastleMove:
            # Kiểm tra nếu nhập thành bên vua
            if move.endCol-move.startCol==2:
                
                self.board[move.endRow][move.endCol-1]=self.board[move.endRow][move.endCol+1]
                self.board[move.endRow][move.endCol+1]='--' 
            else:
                
                self.board[move.endRow][move.endCol+1]=self.board[move.endRow][move.endCol-2]
                self.board[move.endRow][move.endCol-2]='--'
        
        #update castling right -when it is a rook or a king move
        #move.castlingRightBeforeMove = self.currentcastlingRight  # Lưu quyền nhập thành trước nước đi
        self.enpassantPossibleLog.append(self.enpassantPossible)
        self.updateCastleRights(move)
        self.castleRightsLog.append(CastleRights(self.currentcastlingRight.wks,self.currentcastlingRight.bks,
                                                 self.currentcastlingRight.wqs,self.currentcastlingRight.bqs))

    
    def undoMove(self):
        if len(self.moveLog)!=0:#đảm bảo rằng có một động thái để hoàn tác(di lai )
             move= self.moveLog.pop() # xóa nước đi cuối cùng
             self.board[move.startRow][move.startCol]=move.pieceMoved # di chuyển lại quân cờ
             self.board[move.endRow][move.endCol]=move.pieceCaptured# khôi phục quân cờ bị ăn
             self.whiteToMove= not self.whiteToMove #đổi lượt chơi 
             if move.pieceMoved=='wK':
                self.whiteKingLocation=(move.startRow,move.startCol)
             elif move.pieceMoved=='bK':
                self.blackKingLocation=(move.startRow,move.startCol)

            #undo enpassant
             if move.isEnpassantMove:
                 self.board[move.endRow][move.endCol]="--"
                 self.board[move.startRow][move.endCol]=move.pieceCaptured
                 #self.enpassantPossible=(move.endRow,move.endCol)

            #undo a 2 square pawn advance
             #if move.pieceMoved[1]=='p'and abs(move.startRow-move.endRow)==2:
              #   self.enpassantPossible= ()
             self.enpassantPossible = move.enpassantPossibleBeforeMove
            #undo castling right
             self.castleRightsLog.pop() # Xóa trạng thái quyền nhập thành gần nhất khỏi log
             newRights=self.castleRightsLog[-1]
             # cập nhật quyền nhập thành vua sau khi hoàn tác 'z'
             self.currentcastlingRight=CastleRights(newRights.wks,newRights.bks,newRights.wqs,newRights.bqs)
             
             #undo castle move
             if move.isCastleMove:
                 # Kiểm tra nếu là nhập thành bên vua
                 if move.endCol-move.startCol==2:
                     self.board[move.endRow][move.endCol+1]=self.board[move.endRow][move.endCol-1]
                     self.board[move.endRow][move.endCol-1]='--'
                 else:#bên hậu
                     self.board[move.endRow][move.endCol-2]=self.board[move.endRow][move.endCol+1]
                     self.board[move.endRow][move.endCol+1]='--'
             # Khôi phục quyền nhập thành từ trạng thái trước nước đi
             #self.currentcastlingRight = move.castlingRightBeforeMove
             #Add these
             self.checkmate=False
             self.stalemate=False


    def updateCastleRights(self,move):
        # Nếu quân vua di chuyển, mất quyền nhập thành cả hai bên
        if move.pieceMoved=='wK':# Vua trắng di chuyển
            self.currentcastlingRight.wks=False# Mất quyền nhập thành bên vua
            self.currentcastlingRight.wqs=False# Mất quyền nhập thành bên hậu
        elif move.pieceMoved=='bK':# Vua đen di chuyển
            self.currentcastlingRight.bks=False# Mất quyền nhập thành bên vua
            self.currentcastlingRight.bqs=False# Mất quyền nhập thành bên hậu

         # Nếu quân xe di chuyển, mất quyền nhập thành liên quan đến xe đó
        elif move.pieceMoved=='wR':
            if move.startRow==7:# Hàng của trắng
                if move.startCol==0:# Xe ở cột a (hàng 7, cột 0)
                    self.currentcastlingRight.wqs=False# Mất quyền nhập thành bên hậu 
                elif move.startCol==7: # Xe ở cột h (hàng 7, cột 7)
                    self.currentcastlingRight.wks=False# Mất quyền nhập thành bên vua
        elif move.pieceMoved=='bR':
            if move.startRow==0:# Hàng của đen
                if move.startCol==0:
                    self.currentcastlingRight.bqs=False# Mất quyền nhập thành bên hậu 
                elif move.startCol==7:
                    self.currentcastlingRight.bks=False# Mất quyền nhập thành bên vua
        
    


    def getAllPossibleMoves(self):
        
        moves = []
        for r in range(len(self.board)):  # Duyệt từng hàng
            for c in range(len(self.board[r])):  # Duyệt từng cột
                #if self.board[r][c] == "--":  # Bỏ qua ô trống
                    #continue
            
                turn = self.board[r][c][0]  # Lấy màu quân cờ
                if (turn == 'w' and self.whiteToMove) or (turn == 'b' and not self.whiteToMove):  
                    piece = self.board[r][c][1]  # Lấy loại quân cờ
                    #if piece in self.moveFunctions:  # Đảm bảo có hàm di chuyển cho quân cờ này
                    self.moveFunctions[piece](r, c, moves)  # Gọi hàm tương ứng
    

        return moves
        
        


    
    def getValidMoves(self):
        # Reset trạng thái chiếu hết & hòa trước khi kiểm tra lại
        self.checkMade = False
        self.staleMade = False
        
        tempEnpassantPossible =self.enpassantPossible
        temCastleRights=CastleRights(self.currentcastlingRight.wks,self.currentcastlingRight.bks,
                                     self.currentcastlingRight.wqs,self.currentcastlingRight.bqs)
        moves=self.getAllPossibleMoves()
        if self.whiteToMove:
            self.getCastleMoves(self.whiteKingLocation[0],self.whiteKingLocation[1],moves)
        else:
            self.getCastleMoves(self.blackKingLocation[0],self.blackKingLocation[1],moves)
        for i in range(len(moves)-1,-1,-1):
            self.makeMove(moves[i])
            self.whiteToMove=not self.whiteToMove
            if self.inCheck():
                moves.remove(moves[i])
            self.whiteToMove=not self.whiteToMove
            self.undoMove()
        if len(moves)==0:
            if self.inCheck():
                self.checkMade=True
            else:
                self.staleMade=True
        self.enpassantPossible=tempEnpassantPossible
        self.currentcastlingRight=temCastleRights

        return moves
    
    

    
    def checkForPinsandChecks(self):
        pins = []  # Danh sách quân cờ bị ghim
        checks = []  # Danh sách nước chiếu tướng
        inCheck = False  # Hiện tại vua chưa bị chiếu
        
        if self.whiteToMove:
            enemyColor = 'b'
            allyColor = 'w'
            # Vị trí vua trắng
            startRow, startCol = self.whiteKingLocation
        else:
            enemyColor = 'w'
            allyColor = 'b'
            # Vị trí vua đen
            startRow, startCol = self.blackKingLocation

        # Hướng di chuyển của Xe, Tượng, Hậu
        directions = [(-1, 0), (0, -1), (0, 1), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1)]

        # Kiểm tra các hướng để tìm nước chiếu
        for j, d in enumerate(directions):
            possiblePin = ()
            for i in range(1, 8):
                endRow = startRow + d[0] * i
                endCol = startCol + d[1] * i
                if 0 <= endRow < 8 and 0 <= endCol < 8:  # Xem còn trong bàn cờ không
                    endPiece = self.board[endRow][endCol]  # Lấy quân cờ tại ô đó
                    if endPiece[0] == allyColor and endPiece[1] != 'K':  # Nếu là quân đồng minh trừ vua
                        if not possiblePin:  # Nếu chưa có quân nào bị ghim
                            possiblePin = (endRow, endCol, d[0], d[1])  # Lưu vị trí có thể bị ghim
                        else:
                            break
                    elif endPiece[0] == enemyColor:  # Nếu gặp quân địch
                        type = endPiece[1]  # Lấy loại quân cờ

                        if (
                            (j in range(4) and type == 'R') or  # Xe chiếu (đi ngang, dọc)
                            (j in range(4, 8) and type == 'B') or  # Tượng chiếu (đi chéo)
                            (i == 1 and type == 'p' and ((enemyColor == 'w' and j in (6, 7)) or (enemyColor == 'b' and j in (4, 5)))) or  # Tốt chiếu chéo
                            (type == 'Q') or  # Hậu chiếu
                            (i == 1 and type == 'K')  # Vua chiếu trong 1 ô
                        ):
                            if not possiblePin:  # Nếu không có quân nào bị ghim, vua đang bị chiếu
                                inCheck = True
                                checks.append((endRow, endCol, d[0], d[1]))
                                break
                            else:
                                pins.append(possiblePin)
                                break
                        else:
                            break
                else:
                    break  # Đóng bàn cờ

        # Kiểm tra chiếu bởi quân Mã
        knightMoves = [(-2, -1), (-1, -2), (1, 2), (2, 1), (1, -2), (-2, 1), (-1, 2), (2, -1)]
        for m in knightMoves:
            endRow = startRow + m[0]
            endCol = startCol + m[1]
            if 0 <= endRow < 8 and 0 <= endCol < 8:
                endPiece = self.board[endRow][endCol]
                if endPiece[0] == enemyColor and endPiece[1] == 'N':  # Mã địch tấn công vua
                    inCheck = True
                    checks.append((endRow, endCol, m[0], m[1]))  # Lưu vị trí con Mã đang chiếu vua

        return inCheck, pins, checks  # Trả về trạng thái chiếu, danh sách quân bị ghim và các nước chiếu
        



    # kiểm tra vua bên đang đi có bị chiếu không
    def inCheck(self):
        if self.whiteToMove:
            return self.squareUnderAttack(self.whiteKingLocation[0],self.whiteKingLocation[1])
        else:
            return self.squareUnderAttack(self.blackKingLocation[0],self.blackKingLocation[1])
        
    def squareUnderAttack(self,r,c): 

        self.whiteToMove =not self.whiteToMove
        oppMoves =self.getAllPossibleMoves() # lấy danh sách tât cả các nước đi của địch
        self.whiteToMove=not self.whiteToMove # khôi phục lượt chơi
        for move in oppMoves:
            if move.endRow == r and move.endCol== c:# kiểm tra ô (r,c) cố bị quân địch tấn công không
                return True
            
        return False 

    # cài đặt tốt di chuyển 
    def getPawnMoves(self,r,c,moves):
        
        if self.whiteToMove:  #tot trang di chuyen
            if self.board[r-1][c]=="--": # nếu 1ô trước mặt trống
                moves.append(Move((r,c),(r-1,c),self.board)) # tốt di chuyển 1 nước
                if r==6 and self.board[r-2][c]=="--": #khi 2 ô trc mặt trống
                    moves.append(Move((r,c),(r-2,c),self.board)) # tốt di chuyển 2 nước
            if c>=1:
                if self.board[r-1][c-1][0]=="b": # điều kiện tôt ăn chéo trái
                    moves.append(Move((r,c),(r-1,c-1),self.board ))   
                elif (r-1,c-1)==self.enpassantPossible:
                    moves.append(Move((r,c),(r-1,c-1),self.board,isEnpassantMove=True   ))
            if c+1<= 7:
                if self.board [r-1][c+1][0]=="b": # điều kiện tốt ăn chéo phải
                    moves.append(Move((r,c),(r-1,c+1),self.board))
                elif (r-1,c+1)==self.enpassantPossible:
                    moves.append(Move((r,c),(r-1,c+1),self.board,isEnpassantMove=True   ))
        else: #tôt đen di chuyển
            if self.board[r+1][c]=='--': # nếu 1 ô trước mặt trống
                moves.append(Move((r,c),(r+1,c),self.board))
                if r==1 and self.board[r+2][c]=="--": # nếu 2 ô trc mặt trống
                    moves.append(Move((r,c),(r+2,c),self.board))
            # tôt đen ăn mồi
            if c>=1:
                if self.board[r+1][c-1][0]=='w': # điều kiện ăn chéo phải của tôt đen
                    moves.append(Move((r,c),(r+1,c-1),self.board))
                elif (r+1,c-1)==self.enpassantPossible:
                    moves.append(Move((r,c),(r+1,c-1),self.board,isEnpassantMove=True   ))
            if c<=6:
                if self.board[r+1][c+1][0]=='w':# điều kiện ăn chéo trái của tôt đen
                    moves.append(Move((r,c),(r+1,c+1),self.board))
                elif (r+1,c+1)==self.enpassantPossible:
                    moves.append(Move((r,c),(r+1,c+1),self.board,isEnpassantMove=True   ))

    # hàm thêm các nước di chuyển hợp lệ của xe
    def getRookMoves(self,r,c,moves):
        piecePinned=False # Biến kiểm tra xem quân xe có bị ghim không
        pinDirection=() # Hướng ghim của quân xe 
         # Kiểm tra xem quân xe có bị ghim không bằng cách duyệt danh sách các quân bị ghim
        for i in range(len(self.pins)-1,-1,-1):#Duyệt danh sách từ cuối lên đầu để tránh lỗi khi xóa phần tử
            if self.pins[i][0] ==r and self.pins[i][1]==c:# Nếu quân xe bị ghim
                piecePinned=True
                pinDirection=(self.pins[i][2],self.pins[i][3])
                if self.board[r][c][1]!='Q':# Nếu quân cờ không phải hậu (Q), xóa khỏi danh sách pins
                    self.pins.remove(self.pins[i]) # Xóa phần tử tại index i
                break

        directions=((-1,0),(0,-1),(1,0),(0,1))
        enemyColor= "b" if self.whiteToMove else "w"
        for d in directions: # duyệt từng hướng đi của xe
            for i in range(1,8): # 1 mỗi hướng có khả năng đi xa tới 7 ô
                endRow= r+d[0]*i
                endCol= c+d[1]*i
                if 0<=endRow<8 and 0<=endCol<8:# phải trong bàn cờ
                    #nếu quân cờ 0 bị gim hoặc quân cờ bị ghim chỉ có thể đi theo hướng d hoặc đi hướng ngược lại
                    if not piecePinned or pinDirection==d or pinDirection==(-d[0],-d[1]):
                        endPiece =self.board[endRow][endCol]
                    if endPiece=='--': # nếu trống có thể đi
                        moves.append(Move((r,c),(endRow,endCol),self.board))
                    elif endPiece[0]== enemyColor: # gặp địch đớp luôn
                        moves.append(Move((r,c),(endRow,endCol),self.board))
                        break
                    else:
                        break
                else : # nếu nhảy ra khỏi bàn cờ
                    break

    # hàm di chuyển của ngựa    
    def getKnightMoves(self,r,c,moves):
        piecePinned=False # Biến kiểm tra xem quân ngựa có bị ghim không
        pinDirection=()# Hướng ghim của quân ngựa 
        for i in range(len(self.pins)-1,-1,-1):
            if self.pins[i][0]==r and self.pins[i][1]==c:
                piecePinned =True
                pinDirection = (self.pins[i][2],self.pins[i][3])
                self.pins.remove(self.pins[i])
                break
        # các hướng đi của ngựa
        directions=((-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1))
        enemyColor= "b" if self.whiteToMove else "w"
        for dr,dc in directions:
            endRow = r + dr
            endCol = c + dc

            if 0 <= endRow < 8 and 0 <= endCol < 8:  # Kiểm tra trong bàn cờ
                if not piecePinned:
                    endPiece = self.board[endRow][endCol]# Lấy quân cờ ở vị trí mới
                # Nếu ô trống hoặc có quân địch thì ngựa có thể nhảy đến đó
                if endPiece == "--" or endPiece[0] == enemyColor:  
                    moves.append(Move((r,c),(endRow,endCol),self.board))
        
    # hàm di chuyển của tượng
    def getBishopMoves(self,r,c,moves):
        
        piecePinned=False # Biến kiểm tra xem quân voi có bị ghim không
        pinDirection=() # Hướng ghim của quân voi 
         # Kiểm tra xem quân voi có bị ghim không bằng cách duyệt danh sách các quân bị ghim
        for i in range(len(self.pins)-1,-1,-1):#Duyệt danh sách từ cuối lên đầu để tránh lỗi khi xóa phần tử
            if self.pins[i][0] ==r and self.pins[i][1]==c:# Nếu quân voi bị ghim
                piecePinned=True
                pinDirection=(self.pins[i][2],self.pins[i][3])
                if self.board[r][c][1]!='Q':# Nếu quân cờ không phải hậu (Q), xóa khỏi danh sách pins
                    self.pins.remove(self.pins[i]) # Xóa phần tử tại index i
                break
        directions=((-1,-1),(-1,1),(1,-1),(1,1))
        enemyColor= "b" if self.whiteToMove else "w"
        for d in directions:
            for i in range(1,8):
                endRow=r +d[0]*i
                endCol=c +d[1]*i
                if 0<=endRow<8 and 0<=endCol<8:# phải trong bàn cờ
                    
                    #nếu quân cờ 0 bị gim hoặc quân cờ bị ghim chỉ có thể đi theo hướng d hoặc đi hướng ngược lại
                    if not piecePinned or pinDirection==d or pinDirection==(-d[0],-d[1]):
                        endPiece = self.board[endRow][endCol]  # Luôn gán giá trị cho `endPiece
                        if endPiece=='--': # nếu trống có thể đi
                            moves.append(Move((r,c),(endRow,endCol),self.board))
                        elif endPiece[0]== enemyColor: # gặp địch đớp luôn
                            moves.append(Move((r,c),(endRow,endCol),self.board))
                            break
                        else:
                            break
                else : # nếu nhảy ra khỏi bàn cờ
                    break
    # hàm di chuyển của hậu
    def getQueenMoves(self,r,c,moves):
        self.getRookMoves(r,c,moves) # đi giống xe
        self.getBishopMoves(r,c,moves) # đi như tịnh

    
    #hàm di chuyển của vua
    
    def getKingMoves(self,r,c,moves):
        rowMoves=(-1,-1,-1,0,0,1,1,1) # Các hướng di chuyển hàng
        colMoves=(-1,1,0,1,-1,-1,0,1)# Các hướng di chuyển cột
        allyColor="w" if self.whiteToMove else "b" # Xác định màu của quân cờ đang đi

        for i in range(8):# Kiểm tra từng hướng có thể đi
            endRow= r+rowMoves[i]
            endCol= c+colMoves[i]
            if 0<=endCol<8 and 0<=endRow<8:
                endPiece=self.board[endRow][endCol] # Lấy quân cờ tại ô đích
                if endPiece[0]!=allyColor:# Chỉ có thể đi vào ô trống hoặc ô có quân địch
                    # Tạm thời cập nhật vị trí vua để kiểm tra xem nước đi này có khiến vua bị chiếu không
                    if allyColor=='w': 
                        self.whiteKingLocation=(endRow,endCol)
                    else:
                        self.blackKingLocation=(endRow,endCol)
                    # Kiểm tra nếu vua có bị chiếu sau khi đi vào ô này không
                    inCheck, pins,checks =self.checkForPinsandChecks()
                    if not inCheck:# Nếu vua không bị chiếu sau khi đi vào ô này
                        moves.append(Move((r,c),(endRow,endCol),self.board))# Thêm nước đi hợp lệ
                    # Khôi phục vị trí ban đầu của vua sau khi kiểm tra
                    if allyColor=='w':
                        self.whiteKingLocation=(r,c)
                    else:
                        self.blackKingLocation=(r,c)
        #self.getCastleMoves(r,c,moves)
    
    
    def getCastleMoves(self,r,c,moves):
        if self.squareUnderAttack(r,c): # Nếu vua đang bị chiếu, không thể nhập thành
            return
        # Kiểm tra quyền nhập thành bên vua
        if (self.whiteToMove and self.currentcastlingRight.wks) or(not self.whiteToMove and self.currentcastlingRight.bks):
            self.getKingsideCastleMoves(r,c,moves,)
            # Kiểm tra quyền nhập thành bên hậu
        if (self.whiteToMove and self.currentcastlingRight.wqs) or(not self.whiteToMove and self.currentcastlingRight.bqs):
            self.getQueensideCastleMoves(r,c,moves)
    
    def getKingsideCastleMoves(self,r,c,moves):
        if self.board[r][c+1]=='--' and self.board[r][c+2]=='--':# Kiểm tra xem hai ô bên phải vua có trống không
            # Kiểm tra xem các ô vua đi qua có bị tấn công không
            if not self.squareUnderAttack(r,c+1) and not self.squareUnderAttack(r,c+2):
                moves.append(Move((r,c),(r,c+2),self.board,isCastleMove=True))# Nếu hợp lệ, thêm nước đi nhập thành vào danh sách'''
    '''
    def getKingsideCastleMoves(self,r,c,moves,allyColor):
        if self.board[r][c+1]=='--' and self.board[r][c+2]=='--' and \
        not self.squareUnderAttack(r,c+1,allyColor) and not self.squareUnderAttack(r,c+2,allyColor):
            moves.append(Move((r,c),(r,c+2),self.board,castle=True))'''
    

    
    def getQueensideCastleMoves(self,r,c,moves):
        # Kiểm tra xem hai ô bên trái vua có trống không
        if self.board[r][c-1]=='--'and self.board[r][c-2]=='--'and self.board[r][c-3]:
            # Kiểm tra xem các ô vua đi qua có bị tấn công không
            if not self.squareUnderAttack(r,c-1) and not self.squareUnderAttack(r,c-2):
                # Nếu hợp lệ, thêm nước đi nhập thành vào danh sách
                moves.append(Move((r,c),(r,c-2),self.board,isCastleMove=True))
    '''
    def getQueensideCastleMoves(self,r,c,moves,allyColor):
        if self.board[r][c-1]=='--' and self.board[r][c-2]=='--'and self.board[r][c-3]=='--'and \
        not self.squareUnderAttack(r,c-1,allyColor)and not self.squareUnderAttack(r,c,allyColor):
            moves.append(Move((r,c),(r,c-2),self.board,castle=True))'''


class CastleRights():
    def __init__(self,wks,bks,wqs,bqs):
        self.wks=wks
        self.bks=bks
        self.wqs=wqs
        self.bqs=bqs
                
class Move():
    # map key value
    #key:value
    ranksToRows={"1":7,"2":6,"3":5,"4":4,
                 "5":3,"6":2,"7":1,"8":0}
    rowstoRanks={v:k for k,v in ranksToRows.items()}
    filesToCols ={"a":0,"b":1,"c":2,"d":3,
                  "e":4,"f":5,"g":6,"h":7}
    colToFiles ={v:k for k,v in filesToCols.items()}


    def __init__(self, startSg, endSg, board, isEnpassantMove=False, isCastleMove=False):
        # Khởi tạo vị trí bắt đầu và kết thúc của nước đi
        self.startRow = startSg[0]
        self.startCol = startSg[1]
        self.endRow = endSg[0]
        self.endCol = endSg[1]
        
        # Lấy quân cờ ở ô bắt đầu và ô kết thúc
        self.pieceMoved = board[self.startRow][self.startCol]
        self.pieceCaptured = board[self.endRow][self.endCol]
        
        # Kiểm tra xem có phải là nước đi nhập thành hay không
        self.isCastleMove = isCastleMove
        
        # Kiểm tra xem nước đi có phải là en passant hay không
        self.isEnpassantMove = isEnpassantMove
        if self.isEnpassantMove:
            # Nếu là en passant, quân cờ bị bắt là quân đối phương đi tốt vào vị trí en passant
            self.pieceCaptured = 'wp' if self.pieceMoved == 'bp' else 'bp'
        
        # Kiểm tra xem nước đi có phải là nước ăn quân hay không
        self.isCapture = self.pieceCaptured != '--'
        
        # Kiểm tra nước đi thăng cấp cho tốt
        self.isPawnPromotion = (self.pieceMoved == "wp" and self.endRow == 0) or (self.pieceMoved == "bp" and self.endRow == 7)
        
        # Tạo ID cho nước đi, giúp dễ dàng nhận diện và lưu trữ nước đi
        self.moveID = self.startRow * 1000 + self.startCol * 100 + self.endRow * 10 + self.endCol


    ''' overriding  the equal method'''
    def __eq__(self, other):
        if isinstance(other,Move):
            return self.moveID==other.moveID
        return False

         

    def getChessNotation(self):
        # thêm vào cho đẹp
        return self.getRankFile(self.startRow,self.startCol)+self.getRankFile(self.endRow,self.endCol)


    def getRankFile(self,r,c):    
        return self.colToFiles[c]+self.rowstoRanks[r]
    
    def __str__(self):
        #castle move
        if self.isCastleMove:
            return"0-0" if self.endCol==6 else "0-0-0"
        endSquare=self.getRankFile(self.endRow,self.endCol)
        #pawn move
        if self.pieceMoved[1]=='p':
            if self.isCapture:
                return self.colToFiles[self.startCol]+"x"+endSquare
            else:
                return endSquare   
            #pawn promotion
        #piece move
        moveString= self.pieceMoved[1]
        if self.isCapture:
            moveString+='x'
        return moveString+endSquare

'''
class NullMove:
    def __init__(self):
        self.startRow = -1
        self.startCol = -1
        self.endRow = -1
        self.endCol = -1
        self.pieceMoved = "--"  # Thay vì None, đặt giá trị mặc định cho pieceMoved
        #self.pieceMoved = None  # Không có quân cờ di chuyển trong NullMove
        self.pieceCaptured = None  # Không có quân cờ bị bắt
        self.isCastleMove = False  # Không phải nhập thành
        self.isPawnPromotion = False  # Không phải nước đi thăng quân
        self.moveID = None  # ID của nước đi, có thể để là None cho NullMove
        self.isEnpassantMove=False#Không phải nước đi en passant
    def __str__(self):
        return "Null Move"

    def __eq__(self, other):
        return isinstance(other, NullMove)

    def __ne__(self, other):
        return not self.__eq__(other)'''
class NullMove:
    def __init__(self):
        # Không có thông tin về quân cờ hay các chỉ số khác
        self.startRow = -1
        self.startCol = -1
        self.endRow = -1
        self.endCol = -1
        self.pieceMoved = None
        self.pieceCaptured = None
        self.isCastleMove = False
        self.isEnpassantMove = False
        self.isPawnPromotion = False
        self.isNullMove = True  # Dễ dàng kiểm tra loại nước đi này

    def __str__(self):
        return "NullMove"  # Trả về chuỗi để dễ dàng nhận diện
