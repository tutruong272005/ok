import random
from ChessEngine import GameState  # Import class GameState từ ChessEngine.py
from ChessEngine import NullMove
pieceScore={"K":0,"Q":10,"R":5,"B":3,"N":3,"p":1}

knightScores=[[0,0,0,0,0,0,0,0],
              [0,1,1,1,1,1,1,0],
              [0,1,0,2,2,0,1,0],
              [0,1,2,2,2,2,1,0],
              [0,1,2,2,2,2,1,0],
              [0,1,0,2,2,0,1,0],
              [0,1,1,1,1,1,1,0],
              [0,0,0,0,0,0,0,0]]
bishopScore=[[4,3,2,1,1,2,3,4],
             [3,4,3,2,2,3,4,3],
             [2,3,4,3,3,4,3,2],
             [1,2,3,4,4,3,2,1],
             [1,2,3,4,4,3,2,1],
             [2,3,4,3,3,4,3,2],
             [3,4,3,2,2,3,4,3],
             [4,3,2,1,1,2,3,4]]
queenScore=[[1,1,1,3,1,1,1,1],
            [1,2,3,3,3,1,1,1],
            [1,3,3,3,3,3,2,1],
            [1,2,3,3,3,2,2,1],
            [1,2,3,3,3,2,2,1],
            [1,3,3,3,3,3,2,1],
            [1,1,2,3,3,1,1,1],
            [1,1,1,3,1,1,1,1]]
rookScore=[[0,0,1,2,2,1,0,0],
           [0,1,2,3,3,2,1,0],
           [1,2,3,4,4,3,2,1],
           [2,3,4,5,5,4,3,2],
           [2,3,4,5,5,4,3,2],
           [1,2,3,4,4,3,2,1],
           [0,1,2,3,3,2,1,0],
           [0,0,1,2,2,1,0,0]]
# whitePawnScores=[[0,0,0,0,0,0,0,0],
#                  [1,1,1,1,1,1,1,1],
#                  [1,2,2,3,3,2,2,1],
#                  [2,3,3,4,4,3,3,2],
#                  [3,4,4,5,5,4,4,3],
#                  [4,5,6,7,7,6,5,4],
#                  [6,7,7,8,8,7,7,6],
#                  [0,0,0,0,0,0,0,0]]
blackPawnScores = [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [2, 2, 2, 2, 2, 2, 2, 2],  # <- hàng 1 (hàng 7 trong GUI) khởi đầu nên để cao hơn
    [2, 6, 6, 4, 4, 6, 6, 2],
    [2, 3, 6, 4, 4, 6, 3, 2],
    [1, 2, 3, 4, 4, 3, 2, 1],
    [5, 6, 6, 6, 6, 6, 6, 5],
    [2, 2, 2, 2, 2, 2, 2, 2],
    [0, 0, 0, 0, 0, 0, 0, 0],
]


whitePawnScores = [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [2, 2, 2, 2, 2, 2, 2, 2],
    [5, 6, 6, 6, 6, 6, 6, 5],
    [1, 2, 3, 4, 4, 3, 2, 1],
    [2, 3, 6, 4, 4, 6, 3, 2],
    [2, 6, 6, 4, 4, 6, 6, 2],
    [2, 2, 2, 2, 2, 2, 2, 2],  # <- Tốt đen ở hàng 1 (row = 6): tăng điểm khởi đầu
    [0, 0, 0, 0, 0, 0, 0, 0],
]
piecePositionScores={"N":knightScores,"Q":queenScore,"B":bishopScore,"R":rookScore,"bp":blackPawnScores,"wp":whitePawnScores}

CHECKMATE=1000# Điểm số khi chiếu hết
STALEMATE=0# Điểm số khi hòa
DEPTH =4 #độ sâu tìm kiếm
transposition_table = {}  # Bảng ghi nhớ trạng thái cờ
killer_moves = {}  # Killer moves heuristic
history_heuristic = {}  # Lịch sử nước đi
'''
def quiescence_search(gs, alpha, beta, turnMultiplier, depth=0, max_depth=5):
    # Nếu đã đạt đến độ sâu tối đa, dừng tìm kiếm
    if depth >= max_depth:
        return turnMultiplier * scoreBoard(gs)
    
    stand_pat = turnMultiplier * scoreBoard(gs)
    
    # Nếu tình trạng hiện tại đã đủ xấu để thua (>= beta) thì trả về giá trị beta
    if stand_pat >= beta:
        return beta
    
    # Nếu giá trị hiện tại tốt hơn alpha, cập nhật alpha
    if alpha < stand_pat:
        alpha = stand_pat
    
    # Lấy danh sách các nước đi ăn quân
    capture_moves = [move for move in gs.getValidMoves() if move.is_capture]
    
    # Sắp xếp các nước đi để thử các nước đi mạnh trước
    capture_moves.sort(key=lambda move: evaluateMove(gs, move), reverse=True)
    
    # Duyệt qua các nước đi ăn quân
    for move in capture_moves:
        gs.makeMove(move)
        
        # Đệ quy gọi lại quiescence_search cho nước đi đã thực hiện
        score = -quiescence_search(gs, -beta, -alpha, -turnMultiplier, depth + 1, max_depth)
        
        gs.undoMove()
        
        # Nếu score đã vượt qua beta, cắt tỉa và trả về beta
        if score >= beta:
            return beta
        
        # Nếu score tốt hơn alpha, cập nhật alpha
        if score > alpha:
            alpha = score
    
    return alpha'''



def findRandomMove(validMoves):# Hàm chọn một nước đi ngẫu nhiên từ danh sách các nước hợp lệ
    # Chọn ngẫu nhiên một nước đi từ danh sách các nước đi hợp lệ
    return validMoves[random.randint(0,len(validMoves)-1)]

def findBestMoveMinMaxNoRecursion(gs,validMoves ):# Hàm tìm nước đi tốt nhất cho người chơi hiện tại
    # Nếu là lượt của Trắng, hệ số là 1, nếu là Đen, hệ số là -1
    turnMultiplier =1 if gs.whiteToMove else -1
    opponentMinMaxScore=-CHECKMATE # Điểm tệ nhất có thể cho đối thủ
    
    bestPlayerMove=None# Biến lưu nước đi tốt nhất của người chơi
    # Trộn danh sách nước đi hợp lệ để tránh kết quả lặp lại khi có nước đi có điểm số giống nhau
    random.shuffle(validMoves)
    for playerMove in validMoves:# Duyệt qua tất cả các nước đi hợp lệ
        gs.makeMove(playerMove)
        opponentsMoves=gs.getValidMoves()# Lấy danh sách nước đi hợp lệ của đối thủ sau nước đi này

         # Nếu ván cờ hòa (stalemate), điểm của đối thủ là 0
        if gs.stalemate:
            opponentMaxScore=STALEMATE
         # Nếu đối thủ bị chiếu hết (checkmate), điểm của đối thủ là -CHECKMATE
        elif gs.checkmate:
            opponentMaxScore=-CHECKMATE
        else:
            opponentMaxScore=-CHECKMATE

            for opponentsMove in opponentsMoves:# Duyệt qua tất cả nước đi của đối th
                gs.makeMove(opponentsMove)
                gs.getValidMoves()

                if gs.checkmate:
                    score=CHECKMATE
                 # Nếu sau nước đi này, ván cờ hòa -> Điểm bằng STALEMATE
                elif gs.stalemate:
                    score=STALEMATE
                else:
                    score=-turnMultiplier*scoreMaterial(gs.board)
                if score>opponentMaxScore:
                    opponentMaxScore=score
                    
                gs.undoMove()   
        ## Nếu điểm đối thủ sau nước đi này thấp hơn điểm tốt nhất của họ trước đó -> Cập nhật nước đi tốt nhất
        if opponentMinMaxScore<opponentMaxScore:
            opponentMinMaxScore=opponentMaxScore
            bestPlayerMove=playerMove
        gs.undoMove()
    return bestPlayerMove# Trả về nước đi tốt nhất tìm được

def findBestMove(gs, validMoves, returnQueue):
    global nextMove, counter
    counter = 0   
    nextMove = None

    if not validMoves:
        returnQueue.put(None)
        return

    # Loại bỏ các nước đi dẫn đến trạng thái đã lặp 2 lần nếu có nước khác
    filteredMoves = []
    for move in validMoves:
        gs.makeMove(move)
        board_state = str(gs.board)
        gs.undoMove()

        if gs.repetitionTable.get(board_state, 0) < 2:
            filteredMoves.append(move)

    # Nếu vẫn còn nước đi hợp lệ sau khi lọc, chỉ xét những nước đó
    if filteredMoves:
        validMoves = filteredMoves  

    # Gọi thuật toán tìm nước đi tốt nhất
    findMoveNegaMaxAlphaBeta(gs, validMoves, DEPTH, -CHECKMATE, CHECKMATE, 1 if gs.whiteToMove else -1)

    print("Số trạng thái đã đánh giá:", counter)
    returnQueue.put(nextMove)




def findMoveMinMax(gs,validMoves,depth,whiteToMove):
    global nextMove
    if depth==0:# Khi đạt đến độ sâu mong muốn, trả về điểm đánh giá của bàn cờ hiện tại
        return scoreMaterial(gs.board)
    
    if whiteToMove:
        maxScore=-CHECKMATE
        for move in validMoves:
            gs.makeMove(move)
            nextMove=gs.getValidMoves() # Lấy danh sách nước đi hợp lệ tiếp theo của đối thủ
            # Gọi đệ quy để tìm điểm số của bàn cờ sau nước đi này, với lượt tiếp theo là Đen
            score=findMoveMinMax(gs,nextMove,depth-1,False)
            if score>maxScore:
                maxScore =score
                if depth== DEPTH:# Nếu đang ở độ sâu gốc, lưu nước đi tốt nhất
                    nextMove=move
            gs.undoMove()
        return maxScore# Trả về điểm số cao nhất tìm được
    
    else:# Nếu là lượt của Đen
        minScore=CHECKMATE
        for move in validMoves:
            gs.makeMove(move)
            nextMove=gs.getValidMoves()
            # Gọi đệ quy để tìm điểm số của bàn cờ sau nước đi này, với lượt tiếp theo là Trắng
            score=findMoveMinMax(gs,nextMove,depth-1,True)
            if score<minScore:
                minScore=score
                if depth==DEPTH:
                    nextMove=move
            gs.undoMove()
        return minScore

def negamax(gs, depth, alpha, beta, turnMultiplier):
    if depth == 0:
        return quiescence_search(gs, alpha, beta, turnMultiplier)
    
    max_score = float('-inf')
    
    for move in gs.getValidMoves():
        gs.makeMove(move)
        score = -negamax(gs, depth - 1, -beta, -alpha, -turnMultiplier)
        gs.undoMove()
        
        max_score = max(max_score, score)
        alpha = max(alpha, score)
        
        if alpha >= beta:
            break
    
    return max_score

def scoreMove(move):
    score = 0
    if move.isCapture:
        score += 10 + move.capturedPieceValue
    if move.isCheck:
        score += 5
    return score

def get_history_score(move):
    key = (move.startRow, move.startCol, move.endRow, move.endCol)
    return history_heuristic.get(key, 0)
'''
def getAdaptiveDepth(gs):
    total_pieces = sum(1 for row in gs.board for square in row if square != "--")
    if total_pieces > 15:
        return 4  # Tàn cuộc sớm: không cần đi sâu
    
    else:
        return 5  # Tàn cuộc: ít quân, cần đi sâu hơn để tính sát cờ'''
def getAdaptiveDepth(gs):
    total_pieces = sum(1 for row in gs.board for square in row if square != "--")
    
    
    if total_pieces > 16:
        return 4  #  vẫn đông quân, cần giữ tốc độ
    elif total_pieces > 8:
        return 5  # Tàn cuộc trung bình: có thể đi sâu hơn
    else:
        return 6  # Cận tàn cuộc: ít quân → đi thật sâu để tính sát cờ




from collections import OrderedDict
from dataclasses import dataclass

# Một entry trong bảng ghi nhớ Transposition Table
@dataclass
class TTEntry:
    score: int        # Điểm đánh giá trạng thái bàn cờ
    depth: int        # Độ sâu của thuật toán khi ghi lại entry này
    flag: str         # Cờ dùng để xác định loại kết quả: 
                      # "EXACT" - giá trị chính xác
                      # "LOWERBOUND" - giá trị thấp nhất có thể (alpha)
                      # "UPPERBOUND" - giá trị cao nhất có thể (beta)

# Bộ nhớ đệm theo kiểu LRU (Least Recently Used)
class LRUCache(OrderedDict):
    def __init__(self, capacity=100000):
        super().__init__()
        self.capacity = capacity  # Sức chứa tối đa của cache

    def __setitem__(self, key, value):
        if key in self:
            self.move_to_end(key)  # Di chuyển key lên cuối để đánh dấu là mới được sử dụng
        super().__setitem__(key, value)
        if len(self) > self.capacity:
            self.popitem(last=False)  # Nếu vượt quá sức chứa, loại bỏ phần tử ít dùng nhất (đầu tiên)

# Khởi tạo bảng ghi nhớ toàn cục (global transposition table)
transposition_table = LRUCache()


def zobrist_hash(gs):
    return hash(gs.fen())  # Bạn có thể thay bằng `gs.fen()` nếu dùng chess library



def findMoveNegaMaxAlphaBeta(gs, validMoves, depth, alpha, beta, turnMultiplier):
    global nextMove, counter
    counter += 1  # Đếm số node đã xét (dùng để thống kê)

    # Thay đổi depth dựa trên tình hình trên bàn cờ'''
    adaptive_depth = getAdaptiveDepth(gs)
    # Sử dụng depth thích ứng
    depth = min(depth, adaptive_depth)  # Đảm bảo không vượt quá depth tối đa đã định'''

    alpha_orig = alpha  # Cần lưu alpha ban đầu để xác định flag sau

    # --- Transposition Table: Check ---
    key = zobrist_hash(gs)
    if key in transposition_table:
        entry = transposition_table[key]
        if entry.depth >= depth:
            if entry.flag == "EXACT":
                return entry.score
            elif entry.flag == "LOWERBOUND":
                alpha = max(alpha, entry.score)
            elif entry.flag == "UPPERBOUND":
                beta = min(beta, entry.score)
            if alpha >= beta:
                return entry.score
            
    if depth == 0:
        # Trường hợp cơ bản: khi đạt đến độ sâu tối đa, trả về điểm của bàn cờ
        return turnMultiplier * scoreBoard(gs)

    maxScore = -CHECKMATE  # Giá trị khởi tạo cho điểm tốt nhất
    bestMove = None        # Nước đi tốt nhất tại node này

    # --- Giai đoạn 1: Tính điểm cho từng nước đi ---
    for move in validMoves:
        base_score = evaluateMove(gs, move)           # Ưu tiên nước đi tấn công, ăn quân, chiếu
        history_score = get_history_score(move)       # Lấy điểm từ history heuristic (ưu tiên nước đi hiệu quả trong quá khứ)
        move.score = base_score + history_score * 0.1 # Kết hợp 2 loại điểm
    


    # --- Giai đoạn 2: Sắp xếp nước đi theo điểm giảm dần ---
    #if depth >= DEPTH - 1:
    validMoves.sort(key=lambda move: move.score, reverse=True)  # Giúp cắt tỉa Alpha-Beta hiệu quả hơn
    
    # --- Null Move Pruning ---
    NULL_MOVE_REDUCTION = 2
    if not gs.inCheck() and depth >= 3:
        gs.whiteToMove = not gs.whiteToMove  # Đảo lượt (bỏ lượt)
        nullMoves = gs.getValidMoves()
        null_score = -findMoveNegaMaxAlphaBeta(gs, nullMoves, depth - 1 - NULL_MOVE_REDUCTION, -beta, -beta + 1, -turnMultiplier)
        gs.whiteToMove = not gs.whiteToMove  # Khôi phục lượt

        if null_score >= beta:
            return beta  # Cắt tỉa do null move pruning

    # --- Giai đoạn 3: Duyệt qua các nước đi đã được sắp xếp ---
    for  move in (validMoves):
        gs.makeMove(move)  # Thực hiện nước đi
        nextMoves = gs.getValidMoves()  # Sinh nước đi tiếp theo
        # Nếu nước đi hiện tại là chiếu vua, cho phép thuật toán tìm kiếm đi sâu hơn 1 lớp
        
        # Gọi đệ quy, đảo chiều turnMultiplier và đảo alpha-beta cho NegaMax
        score = -findMoveNegaMaxAlphaBeta(gs, nextMoves, depth - 1, -beta, -alpha, -turnMultiplier)
        gs.undoMove()  # Hoàn tác nước đi

        # Nếu điểm tốt hơn điểm tốt nhất hiện tại, cập nhật
        if score > maxScore:
            maxScore = score
            bestMove = move
            if depth == DEPTH:
                nextMove = move  # Lưu nước đi nếu đang ở root (lượt của AI)

        # Cập nhật alpha và kiểm tra điều kiện cắt tỉa
        alpha = max(alpha, maxScore)
        if alpha >= beta:
            break  # Cắt tỉa: không cần xét các nhánh còn lại

    # --- Giai đoạn 4: Cập nhật history heuristic và killer move ---
    if bestMove:
        
        move_key = (bestMove.startRow, bestMove.startCol, bestMove.endRow, bestMove.endCol)
        history_heuristic[move_key] = history_heuristic.get(move_key, 0) + depth * depth  # Tăng điểm cho nước đi hiệu quả
        killer_moves[depth] = bestMove  # Ghi nhận nước đi "sát thủ" ở độ sâu này'''
        
    # --- Cập nhật Transposition Table ---
    if maxScore <= alpha_orig:
        flag = "UPPERBOUND"
    elif maxScore >= beta:
        flag = "LOWERBOUND"
    else:
        flag = "EXACT"

    transposition_table[key] = TTEntry(score=maxScore, depth=depth, flag=flag)

    return maxScore  # Trả về điểm cao nhất tìm được tại node này








'''
def evaluateMove(gs, move):
    """
    Đánh giá nước đi dựa trên:
    - Giá trị quân bị ăn
    - Chiếu tướng
    - Nhập thành
    - Tránh lặp trạng thái bàn cờ
    - Ưu tiên nước đi lịch sử và killer move
    """
    pieceValue = {"K": 0, "Q": 10, "R": 5, "B": 3, "N": 3, "p": 1}
    attackBonus = 3  # Điểm thưởng khi ăn quân
    checkBonus = 5  # Điểm thưởng khi chiếu tướng
    castlingBonus = 5  # Điểm thưởng khi nhập thành
    repetitionPenalty = -20  # Phạt nếu lặp trạng thái
    pawnAdvanceBonus = 6   # Cộng khi tốt tiến lên
    pawnPositionWeight = 0.5  # Hệ số điểm vị trí tốt


    score = 0

    # Kiểm tra killer move: nếu nước đi là killer move, cộng điểm
    if move in killer_moves.values():
        score += 8  # Ưu tiên killer move

    # Kiểm tra lịch sử nước đi: nếu nước đi có tần suất cao, cộng điểm
    move_key = (move.startRow, move.startCol, move.endRow, move.endCol)
    history_score = history_heuristic.get(move_key, 0)
    score += history_score * 0.2  # Điều chỉnh hệ số ưu tiên cho lịch sử (có thể tăng lên nếu cần)

    # Lấy quân đi
    moving_piece = gs.board[move.startRow][move.startCol]
    piece_type = moving_piece[1]
    moved_piece_value = pieceValue.get(piece_type, 0)

    # Ưu tiên đẩy tốt để mở đường và chiếm trung tâm
    if piece_type == 'p':
        startRow, startCol = move.startRow, move.startCol
        endRow, endCol = move.endRow, move.endCol

        # Ưu tiên đẩy tốt trung tâm đầu ván (e4, d4, e5, d5)
        central_pawn_pushes = [
            (6, 4, 4, 4), (6, 3, 4, 3),  # Trắng: e2-e4, d2-d4
            (1, 4, 3, 4), (1, 3, 3, 3)   # Đen: e7-e5, d7-d5
        ]
        if (startRow, startCol, endRow, endCol) in central_pawn_pushes:
            score += 25

        # Ưu tiên đẩy tốt nói chung
        if gs.whiteToMove and endRow < startRow:
            score += pawnAdvanceBonus
            score += whitePawnScores[endRow][endCol] * pawnPositionWeight
        elif not gs.whiteToMove and endRow > startRow:
            score += pawnAdvanceBonus
            score += blackPawnScores[endRow][endCol] * pawnPositionWeight

    # Nếu ăn quân, cộng điểm theo giá trị quân bị ăn
    capturedPiece = move.pieceCaptured if hasattr(move, 'pieceCaptured') else gs.board[move.endRow][move.endCol]
    moving_piece = move.pieceMoved if hasattr(move, 'pieceMoved') else gs.board[move.startRow][move.startCol]

    if capturedPiece != "--":
        captured_value = pieceValue.get(capturedPiece[1], 0)
        mover_value = pieceValue.get(moving_piece[1], 0)

        exchange_gain = captured_value - mover_value
        score += captured_value + attackBonus

        if exchange_gain < 0:
            score += exchange_gain * 2  # Ví dụ mã ăn hậu: -12 điểm
        elif exchange_gain == 0:
            score -= 5  # Hòa quân


    
        # Nếu nước đi dẫn đến chiếu tướng, kiểm tra xem có an toàn không
    gs.makeMove(move)

    gs.whiteToMove = not gs.whiteToMove  # Đảo phe để kiểm tra bị tấn công
    is_safe = not gs.squareUnderAttack(move.endRow, move.endCol)  # Phe địch có tấn công ô đến không?
    vulnerable_after = not is_safe  # Nếu không an toàn thì có thể bị ăn
    gs.whiteToMove = not gs.whiteToMove  # Khôi phục phe

    is_check = gs.inCheck()
    gs.undoMove()

    # Phạt nếu ô đích bị tấn công
    if vulnerable_after:
        retaliation_penalty = moved_piece_value * 8
        score -= retaliation_penalty
        
        #Nếu ô đích không an toàn → phạt theo giá trị quân
        if not is_safe:
            danger_penalty = pieceValue.get(piece_type, 0) * 5  # Gấp 5 lần giá trị quân
            score -= danger_penalty

        # Nếu nhập thành, cộng điểm
        if move.isCastleMove:
            score += castlingBonus

        # Nếu nước đi lặp trạng thái cũ, trừ điểm
        board_state = str(gs.boardAfterMove(move))
        if gs.repetitionTable.get(board_state, 0) > 1:
            score += repetitionPenalty
    

    return score'''

def evaluateMove(gs, move):
    """
    Đánh giá nước đi:
    - MVV-LVA (ăn quân có lời)
    - Chiếu tướng, nhập thành
    - Tránh bị ăn lại
    - Đẩy tốt trung tâm
    - Lịch sử nước đi, killer move
    """
    pieceValue = {"K": 0, "Q": 9, "R": 5, "B": 3, "N": 3, "p": 1}
    score = 0

    # --- Killer move ---
    if move in killer_moves.values():
        score += 50

    # --- History heuristic ---
    move_key = (move.startRow, move.startCol, move.endRow, move.endCol)
    score += history_heuristic.get(move_key, 0) * 0.2

    # --- Ưu tiên đẩy tốt trung tâm đầu ván ---
    if move.pieceMoved[1] == 'p':
        if gs.whiteToMove and move.endRow < move.startRow:
            score += 10  # Tốt trắng tiến
            score += whitePawnScores[move.endRow][move.endCol] * 0.5
        elif not gs.whiteToMove and move.endRow > move.startRow:
            score += 10  # Tốt đen tiến
            score += blackPawnScores[move.endRow][move.endCol] * 0.5

        if (move.startRow, move.startCol, move.endRow, move.endCol) in [
            (6, 4, 4, 4), (6, 3, 4, 3),  # e2-e4, d2-d4
            (1, 4, 3, 4), (1, 3, 3, 3)   # e7-e5, d7-d5
        ]:
            score += 30  # Trung tâm đầu ván

    # --- MVV-LVA: Ăn quân ---
    captured = move.pieceCaptured if hasattr(move, 'pieceCaptured') else gs.board[move.endRow][move.endCol]
    if captured != "--":
        victim = pieceValue.get(captured[1], 0)
        attacker = pieceValue.get(move.pieceMoved[1], 0)
        exchange = victim - attacker
        score += victim * 10  # Giá trị quân bị ăn
        if exchange > 0:
            score += 20  # Ăn lời
        elif exchange == 0:
            score += 5   # Hòa quân
        else:
            score -= abs(exchange) * 10  # Ăn lỗ

    # --- Tạm thời thực hiện nước đi ---
    gs.makeMove(move)

    # Đảo lại lượt đi sau khi kiểm tra chiếu
    gs.whiteToMove = not gs.whiteToMove

    # --- Check chiếu ---
    if gs.inCheck():
        score += 25

    # --- Nhập thành ---
    if move.isCastleMove:
        score += 20

    # --- An toàn sau nước đi ---
    danger_penalty = 0
    moved_type = move.pieceMoved[1]
    value = pieceValue.get(moved_type, 0)
    if gs.squareUnderAttack(move.endRow, move.endCol):
        # Nếu ô mới bị tấn công
        danger_penalty = value * 5
        score -= danger_penalty

    # --- Tránh lặp lại ---
    board_state = str(gs.boardAfterMove(move))
    if gs.repetitionTable.get(board_state, 0) > 1:
        score -= 40  # Lặp lần 2, tránh hòa

    # --- Hoàn tác nước đi ---
    gs.undoMove()

    # Đảo lại lượt đi sau khi kiểm tra hoàn tất
    gs.whiteToMove = not gs.whiteToMove

    return score







def scoreBoard(gs):
    if gs.checkmate:
        return -CHECKMATE if gs.whiteToMove else CHECKMATE
    if gs.stalemate:
        return STALEMATE

    score = 0
    for row in range(8):
        for col in range(8):
            square = gs.board[row][col]
            if square != "--":
                piece_type = square[1]
                piece_value = pieceScore[piece_type]

                # Lấy điểm vị trí phù hợp
                if piece_type == "p":
                    if square[0] == 'w':
                        piecePositionScore = whitePawnScores[row][col]
                    else:
                        piecePositionScore = blackPawnScores[row][col]
                else:
                    piecePositionScore = piecePositionScores.get(piece_type, [[0]*8]*8)[row][col]

                # Tính điểm tổng
                if square[0] == 'w':
                    score += piece_value + piecePositionScore * 0.1
                else:
                    score -= piece_value + piecePositionScore * 0.1

    return score

'''
def scoreBoard(gs):
    if gs.checkmate:
        return -CHECKMATE + gs.moveLog.__len__() if gs.whiteToMove else CHECKMATE - gs.moveLog.__len__()
    if gs.stalemate:
        return STALEMATE

    score = 0
    whiteMaterial = 0
    blackMaterial = 0
    for row in range(8):
        for col in range(8):
            square = gs.board[row][col]
            if square != "--":
                piece_type = square[1]
                color = square[0]
                piece_value = pieceScore[piece_type]
                piecePositionScore = piecePositionScores.get(piece_type, [[0]*8]*8)[row][col] if piece_type != 'K' else 0

                if color == 'w':
                    whiteMaterial += piece_value
                    score += piece_value + piecePositionScore * 0.1
                else:
                    blackMaterial += piece_value
                    score -= piece_value + piecePositionScore * 0.1

    # --- Ưu tiên chiếu đối thủ ---
    if gs.inCheck():
        if gs.whiteToMove:
            score -= 30  # Trừ nhẹ nếu bị chiếu
        else:
            score += 30  # Cộng nhẹ nếu đang chiếu

    # --- Tăng cường đánh giá tàn cuộc ---
    totalMaterial = whiteMaterial + blackMaterial
    if totalMaterial < 1500:  # Tàn cuộc (VD: chỉ còn 1 xe, mã...)
        # Ưu tiên vua tiến ra trung tâm
        score += 0.1 * kingCenterBonus(gs, 'w')
        score -= 0.1 * kingCenterBonus(gs, 'b')

    return score'''

def kingCenterBonus(gs, color):
    for row in range(8):
        for col in range(8):
            piece = gs.board[row][col]
            if piece == color + "K":
                centerRow, centerCol = 3.5, 3.5
                dist = abs(row - centerRow) + abs(col - centerCol)
                return 7 - dist  # Vua càng gần trung tâm → điểm càng cao
    return 0

def scoreMaterial(board):
    score = 0
    for row in range(8):
        for col in range(8):
            square = board[row][col]
            if square != "--":
                piece_value = pieceScore[square[1]]
                if square[0] == 'w':
                    score += piece_value
                elif square[0] == 'b':
                    score -= piece_value
    return score